int main(){
    ofstream write_file(FILE_PATH, ios::app);
    ifstream read_file(FILE_PATH);
    fstream read_write_file(FILE_PATH, ios::in | ios::out);

    if (!write_file.is_open() || !read_file.is_open() || !read_write_file.is_open()){
        cout << "Error opening file " << endl;
    }

    int choice;
    bool exit_requested = false;
    do {
        cout << string(43, '-') << " Menu " << string(43, '-') << endl;
        cout << "1. Add a Movie" << endl;
        cout << "2. Search for a Movie" << endl;
        cout << "3. Delete a Movie" << endl;
        cout << "4. List All Movies" << endl;
        cout << "5. Recommend Movies" << endl;
        cout << "6. Exit" << endl;
        cout << "Enter your choice: ";
        while (!(cin >> choice) || choice < 1 || choice > 6) {
            cout << "Invalid input. Please enter a number between 1 and 6: ";
            cin.ignore();
        }
        
        switch (choice) {
            case 1:
                add_movie(read_write_file);
                break;
            case 2:
                search_movie(read_file);
                break;
            case 3:
                delete_movie(read_write_file);
                break;
            case 4:
                list_movies(read_file);
                break;
            case 5:
                recommend_movies(read_file);
                break;
            case 6:
                cout << "Exiting program. Goodbye!" << endl;
                exit_requested = true;
                break;
            default:
                cout << "Invalid choice. Please enter a number between 1 and 6." << endl;
                break;
        }
    } while (!exit_requested);

    read_file.close();
    write_file.close();
    read_write_file.close();

    return 0;
}
