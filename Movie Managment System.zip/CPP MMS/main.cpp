#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <algorithm>
#include <vector>
#include <iomanip>

#define FILE_PATH "data.txt"

using namespace std;

struct Movie {
    string movie_title;
    string movie_genre;
    double movie_rating;
    int movie_release_year;
};

string to_snake_case(string text) {
    string camel_case;
    for (int i = 0; i < text.size(); i++) {
        if (text[i] == ' ') {
            camel_case += '_';
        } else {
            camel_case += text[i];
        }
    }
    return camel_case;
}

string undo_snake_case(string text) {
    string normal;
    for (int i = 0; i < text.size(); i++) {
        if (text[i] == '_') {
            normal += ' ';
        } else {
            normal += text[i];
        }
    }
    return normal;
}

void print_table_row(string count, string title, string genre, string year, string rating) {
    const int HASH_WIDTH = 5;
    const int TITLE_WIDTH = 30;
    const int GENRE_WIDTH = 30;
    const int YEAR_WIDTH = 15;
    const int RATING_WIDTH = 10;

    cout << left
         << setw(HASH_WIDTH) << count
         << setw(TITLE_WIDTH) << title
         << setw(GENRE_WIDTH) << genre
         << setw(YEAR_WIDTH) << year
         << setw(RATING_WIDTH) << rating
         << endl;
}

bool quick_search_for_title(string title, fstream &file) {
    bool is_already_in_database = false;
    string line;
    while (getline(file, line)) {
        if (line.find(title) != string::npos) {
            is_already_in_database = true;
            break;
        }
    }
    file.clear();
    file.seekg(0, ios::beg);
    return is_already_in_database;
}

void add_movie(fstream &file) {
    Movie movie;

    cout << "------- Add a New Movie -------\n";

    cout << "Enter movie title: ";
    cin.ignore();
    getline(cin, movie.movie_title);
    while (quick_search_for_title(movie.movie_title, file)) {
        cout << "Title already in database, try another one: ";
        getline(cin, movie.movie_title);
    }
    while (movie.movie_title.empty()) {
        cout << "Title cannot be empty. Please enter a valid movie title: ";
        getline(cin, movie.movie_title);
    }

    cout << "Enter movie genre: ";
    getline(cin, movie.movie_genre);
    while (movie.movie_genre.empty()) {
        cout << "Genre cannot be empty. Please enter a valid genre: ";
        getline(cin, movie.movie_genre);
    }

    cout << "Enter release year (e.g., 2023, 2008): ";
    while (!(cin >> movie.movie_release_year) || movie.movie_release_year <= 1800 || movie.movie_release_year > 2030) {
        cin.clear();
        cin.ignore();
        cout << "Please enter a valid release year (e.g., 2023, 2008): ";
    }

    cout << "Enter rating (0.0 - 10.0): ";
    while (!(cin >> movie.movie_rating) || movie.movie_rating < 0.0 || movie.movie_rating > 10.0) {
        cin.clear();
        cin.ignore();
        cout << "Please enter a valid rating (0.0 to 10.0): ";
    }

    movie.movie_title = to_snake_case(movie.movie_title);
    movie.movie_genre = to_snake_case(movie.movie_genre);

    file.clear();
    file.seekp(0, ios::end);
    file << movie.movie_title << " " << movie.movie_genre << " " << movie.movie_release_year << " " << movie.movie_rating << endl;
    cout << "Movie added successfully!\n";
}

void search_movie(ifstream &file) {
    string title_for_search;
    cout << "Enter the title you want to search for: ";
    cin.ignore();
    getline(cin, title_for_search);

    title_for_search = to_snake_case(title_for_search);
    string movie_title, movie_genre, movie_release_year, movie_rating;

    string line;
    bool is_found = false;
    bool shown_banner = false;
    int count = 1;
    while (getline(file, line)) {
        istringstream iss(line);
        iss >> movie_title >> movie_genre >> movie_release_year >> movie_rating;

        if (movie_title == title_for_search || movie_title.find(title_for_search) != string::npos) {
            if (!shown_banner) {
                print_table_row("#", "Title", "Genre", "Released Year", "Rating");
                shown_banner = true;
            }

            movie_title = undo_snake_case(movie_title);
            movie_genre = undo_snake_case(movie_genre);

            print_table_row(to_string(count), movie_title, movie_genre, movie_release_year, movie_rating);
            count += 1;
            is_found = true;
        }
    }

    if (!is_found) {
        cout << "Movie " << title_for_search << " not in database." << endl;
    }

    file.clear();
    file.seekg(0, ios::beg);
}

void delete_movie(fstream &file) {
    string title_to_delete;
    cout << "Enter the title you want to delete: ";
    cin.ignore();
    getline(cin, title_to_delete);

    title_to_delete = to_snake_case(title_to_delete);
    string line;
    bool is_found = false;
    vector<string> lines;
    while (getline(file, line)) {
        if (line.find(title_to_delete) == string::npos) {
            lines.push_back(line);
        } else {
            is_found = true;
        }
    }

    file.clear();
    file.seekp(0, ios::beg);
    file.seekg(0, ios::beg);
    file.close();
    file.open(FILE_PATH, ios::out | ios::trunc);
    for (const auto &line : lines) {
        file << line << endl;
    }

    if (!is_found) {
        cout << "Title not found in database!" << endl;
    } else {
        cout << "Title '" << title_to_delete << "' deleted from database." << endl;
    }

    file.flush();
}

void list_movies(ifstream &file) {
    print_table_row("#", "Title", "Genre", "Released Year", "Rating");
    cout << string(86, '-') << endl;

    string line;
    int count = 1;
    while (getline(file, line)) {
        istringstream iss(line);
        string movie_title, movie_genre, movie_release_year, movie_rating;

        iss >> movie_title >> movie_genre >> movie_release_year >> movie_rating;

        movie_title = undo_snake_case(movie_title);
        movie_genre = undo_snake_case(movie_genre);

        print_table_row(to_string(count), movie_title, movie_genre, movie_release_year, movie_rating);

        count += 1;
    }

    file.clear();
    file.seekg(0, ios::beg);
}

void recommend_movies(ifstream &file) {
    string movie_title, movie_genre;
    double movie_rating;
    int movie_release_year;

    int choice;
    cout << "How do you want your recommendations?" << endl
         << "1. By Genre" << endl
         << "2. By Rating (e.g. 8 : returns movies by rating 8 and onwards)" << endl
         << "3. By Year (e.g. 2021 : returns movies from 2021 and onwards)" << endl
         << "Enter your choice here: ";

    while (!(cin >> choice) || choice < 1 || choice > 3) {
        cout << "Enter a valid input: ";
        cin.clear();
        cin.ignore();
    }

    cin.ignore();
    if (choice == 1) {
        print_table_row("#", "Title", "Genre", "Released Year", "Rating");
        cout << string(86, '-') << endl;

        string desired_genre;
        cout << "Enter Genre: ";
        getline(cin, desired_genre);
        desired_genre = to_snake_case(desired_genre);
        int count = 1;
        bool is_found = false;

        string line;
        while (getline(file, line)) {
            istringstream iss(line);
            iss >> movie_title >> movie_genre >> movie_release_year >> movie_rating;

            if (movie_genre.find(desired_genre) != string::npos) {
                movie_title = undo_snake_case(movie_title);
                movie_genre = undo_snake_case(movie_genre);
                print_table_row(to_string(count), movie_title, movie_genre, to_string(movie_release_year), to_string(movie_rating));
                count += 1;
                is_found = true;
            }
        }

        if (!is_found) {
            cout << "No movies of genre '" << desired_genre << "' found in database." << endl;
        }
    } else if (choice == 2) {
        print_table_row("#", "Title", "Genre", "Released Year", "Rating");
        cout << string(86, '-') << endl;

        double desired_rating;
        cout << "Enter Rating: ";
        cin >> desired_rating;
        int count = 1;

        string line;
        while (getline(file, line)) {
            istringstream iss(line);
            iss >> movie_title >> movie_genre >> movie_release_year >> movie_rating;

            if (movie_rating >= desired_rating) {
                movie_title = undo_snake_case(movie_title);
                movie_genre = undo_snake_case(movie_genre);
                print_table_row(to_string(count), movie_title, movie_genre, to_string(movie_release_year), to_string(movie_rating));
                count += 1;
            }
        }
    } else if (choice == 3) {
        print_table_row("#", "Title", "Genre", "Released Year", "Rating");
        cout << string(86, '-') << endl;
        
        int desired_year;
        cout << "Enter Year: ";
        cin >> desired_year;
        int count = 1;

        string line;
        while (getline(file, line)) {
            istringstream iss(line);

            iss >> movie_title >> movie_genre >> movie_release_year >> movie_rating;

            if (movie_release_year >= desired_year) {
                movie_title = undo_snake_case(movie_title);
                movie_genre = undo_snake_case(movie_genre);
                print_table_row(to_string(count), movie_title, movie_genre, to_string(movie_release_year), to_string(movie_rating));
                count += 1;
            }
        }
    }

    file.clear();
    file.seekg(0, ios::beg);
}

int main() {
    fstream read_write_file;
    ifstream read_file;

    if (!read_write_file.is_open() || !read_file.is_open()) {
        cout << "Error opening file " << endl;
    }

    int choice;
    bool exit_requested = false;

    while (!exit_requested) {
        cout << string(43, '-') << " Menu " << string(43, '-') << endl;
        cout << "1. Add a Movie" << endl;
        cout << "2. Search for a Movie" << endl;
        cout << "3. Delete a Movie" << endl;
        cout << "4. List All Movies" << endl;
        cout << "5. Recommend Movies" << endl;
        cout << "6. Exit" << endl;
        cout << "Enter your choice: ";

        while (!(cin >> choice) || choice < 1 || choice > 6) {
            cout << "Invalid input. Please enter a number between 1 and 6: ";
            cin.clear();
            cin.ignore();
        }

        if (choice == 1) {
            read_write_file.open(FILE_PATH, ios::in | ios::out | ios::app);
            if (read_write_file.is_open()) {
                add_movie(read_write_file);
                read_write_file.close();
            }
        } else if (choice == 2) {
            read_file.open(FILE_PATH);
            if (read_file.is_open()) {
                search_movie(read_file);
                read_file.close();
            }
        } else if (choice == 3) {
            read_write_file.open(FILE_PATH, ios::in | ios::out);
            if (read_write_file.is_open()) {
                delete_movie(read_write_file);
                read_write_file.close();
            }
        } else if (choice == 4) {
            read_file.open(FILE_PATH);
            if (read_file.is_open()) {
                list_movies(read_file);
                read_file.close();
            }
        } else if (choice == 5) {
            read_file.open(FILE_PATH);
            if (read_file.is_open()) {
                recommend_movies(read_file);
                read_file.close();
            }
        } else if (choice == 6) {
            cout << "Exiting program..." << endl;
            exit_requested = true;
        }
    }

    return 0;
}
