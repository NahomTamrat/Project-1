#include <iostream>
#include <string>
#include <sstream>

using namespace std;

int main() {
    string s = "titanic romanc";
    istringstream iss(s);
    string title, genre;
    iss >> title >> genre;
    std::cout << "Title: " << title << std::endl;
    std::cout << "Genre: " << genre << std::endl;
    return 0;
}